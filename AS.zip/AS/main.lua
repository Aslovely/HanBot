-- ��֤
local login = module.load("As" .. player.charName, "Login/login")
if login then
    local login,msg = login.login()
    if login then
        -- װ��Core��
        local Cores = module.load("As" .. player.charName, "Core/Core")
        -- װ��AFK
        local AFK = module.load("As" .. player.charName, "Utility/AFKUtility")
        -- װ��Ӣ�۽ű�
        if player.charName == "Jinx" then
           module.load("As" .. player.charName, "Champion/Jinx/main")
        end
        if player.charName == "Kaisa" then
           module.load("As" .. player.charName, "Champion/Kaisa/main")
        end
    else
        print(msg)
    end
end
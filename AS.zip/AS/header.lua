local champion = {
  Jinx = true,
  Kaisa = true,
  Ashe = true,
  Ezreal = true
}

return{
      id = "As" ..  player.charName ,
      name = "As - " ..  player.charName,
      flag = {
          text = "As - " ..  player.charName,
          color = {
             text = 0xFF999999,
          background1 = 0xFF999999,
          background2 = 0xFF999999
          }
      },
      riot = true,
      load = function ()
          return champion[player.charName]; 
      end
}